package com.ekart.facp.dashboard.service.dtos;

import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 10/06/16.
 */
public class DocumentSearchResponse {

    private List<Map<String, Object>> response;
    private long totalCount;

    public DocumentSearchResponse() {
    }

    public DocumentSearchResponse(List<Map<String, Object>> response, long totalCount) {
        this.response = response;
        this.totalCount = totalCount;
    }

    public List<Map<String, Object>> getResponse() {
        return response;
    }

    public void setResponse(List<Map<String, Object>> response) {
        this.response = response;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    @Override
    public String toString() {
        return "DocumentSearchResponse{" + "response=" + response + ", totalCount=" + totalCount + '}';
    }
}
