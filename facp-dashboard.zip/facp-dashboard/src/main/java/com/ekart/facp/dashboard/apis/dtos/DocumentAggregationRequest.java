package com.ekart.facp.dashboard.apis.dtos;

import com.ekart.facp.dashboard.apis.config.CommonConfigValues;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.AssertTrue;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 17/05/16.
 */

@ApiModel
public class DocumentAggregationRequest {

    @ApiModelProperty(name = "query_params", value = "Search query params")
    @JsonProperty(value = "query_params")
    @NotNull(message = "{document.queryParams.notnull}")
    private Map<String, Object> queryParams;

    @ApiModelProperty(name = "from_created_at", value = "From Created date")
    @JsonProperty(value = "from_created_at")
    private Long fromCreatedAt;

    @ApiModelProperty(name = "to_created_at", value = "To Created date")
    @JsonProperty(value = "to_created_at")
    private Long toCreatedAt;

    @ApiModelProperty(name = "group_by_fields", value = "Aggregation Group by fields")
    @JsonProperty(value = "group_by_fields")
    @NotEmpty(message = "{document.groupByFields.notEmpty}")
    @Size(max = CommonConfigValues.MAX_GROUP_BY_FIELDS, message = "{document.groupByFields.sizeExceeded} "
            + CommonConfigValues.MAX_GROUP_BY_FIELDS)
    private List<String> groupByFields;

    @JsonIgnore
    @AssertTrue(message = "{document.timeRangeFields.present}")
    public boolean isBothFromCreatedAtAndToCreatedAtOrNonePresent() {

        return (fromCreatedAt != null && toCreatedAt != null) || (fromCreatedAt == null && toCreatedAt == null);
    }

    @JsonIgnore
    @AssertTrue(message = "{document.queryParams.notnull}")
    public boolean isRangeParamsOrQueryParamsPresent() {

        return (fromCreatedAt != null && toCreatedAt != null) || !queryParams.isEmpty();
    }

    @JsonIgnore
    @AssertTrue(message = "document.groupByFields.field.notEmpty")
    public boolean isGroupByFieldNotHavingAnyEmptyField() {

        for (String field : groupByFields) {
            if (field.isEmpty()) {
                return false;
            }
        }
        return true;
    }

    public Map<String, Object> getQueryParams() {
        return queryParams;
    }

    public void setQueryParams(Map<String, Object> queryParams) {
        this.queryParams = queryParams;
    }

    public Long getFromCreatedAt() {
        return fromCreatedAt;
    }

    public void setFromCreatedAt(Long fromCreatedAt) {
        this.fromCreatedAt = fromCreatedAt;
    }

    public Long getToCreatedAt() {
        return toCreatedAt;
    }

    public void setToCreatedAt(Long toCreatedAt) {
        this.toCreatedAt = toCreatedAt;
    }

    public List<String> getGroupByFields() {
        return groupByFields;
    }

    public void setGroupByFields(List<String> groupByFields) {
        this.groupByFields = groupByFields;
    }

    @Override
    public String toString() {
        return "DocumentAggregationRequest{" + "queryParams=" + queryParams
                + ", fromCreatedAt=" + fromCreatedAt + ", toCreatedAt=" + toCreatedAt
                + ", groupByFields=" + groupByFields + '}';
    }
}
