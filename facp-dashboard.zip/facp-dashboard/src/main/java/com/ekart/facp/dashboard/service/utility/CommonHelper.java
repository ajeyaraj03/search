package com.ekart.facp.dashboard.service.utility;

/**
 * Created by avinash.r on 02/06/16.
 */
public final class CommonHelper {

    public static String withDocumentPrefix(String arg) {

        return Constants.DOCUMENT_PREFIX + arg;
    }
}
