package com.ekart.facp.dashboard.apis.config.spring;

import com.ekart.facp.dashboard.apis.controller.DashboardController;
import com.ekart.facp.dashboard.apis.controller.DashboardSearchController;
import com.ekart.facp.dashboard.apis.controller.HealthCheckController;
import com.ekart.facp.dashboard.apis.mappers.ApiDtoToServiceDtoMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

import javax.inject.Inject;

@Configuration
@ComponentScan({"com.ekart.facp.dashboard.service.mapper"})
@Import({EnvironmentConfig.class, JettyConfig.class, HealthCheckConfig.class, BusinessServiceConfig.class})
public class ApplicationConfig {

    // Reference:
    // http://docs.spring.io/spring-javaconfig/docs/1.0.0.M4/reference/html/ch04s02.html
    @Inject
    private HealthCheckConfig healthCheckConfig;

    @Inject
    private JettyConfig jettyConfig;

    @Inject
    private BusinessServiceConfig bsConfig;

    @Inject
    private ApiDtoToServiceDtoMapper mapper;

    @Bean
    public HealthCheckController healthCheckController() {

        return new HealthCheckController(healthCheckConfig.masterHealthCheck(), jettyConfig.elbStatisticsCollector());
    }

    @Bean
    public DashboardController dashboardController() {

        return new DashboardController(bsConfig.dashboardService(), mapper);
    }

    @Bean
    public DashboardSearchController dashboardSearchController() {

        return new DashboardSearchController(bsConfig.dashboardService(), mapper);
    }

}
