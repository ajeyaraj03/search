package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import java.util.Map;

/**
 * Created by avinash.r on 08/06/16.
 */
@ApiModel
public class DocumentCountResponse {

    @ApiModelProperty(name = "group_by_fields_and_values", value = "Map of group by field and values")
    @JsonProperty(value = "group_by_fields_and_values", required = true)
    private Map<String, Object> groupByFieldsAndValues;

    @ApiModelProperty(name = "document_count", value = "Count of aggregated documents")
    @JsonProperty(value = "document_count", required = true)
    private long documentCount;

    public DocumentCountResponse() {
    }

    public DocumentCountResponse(Map<String, Object> groupByFieldsAndValues, long documentCount) {
        this.groupByFieldsAndValues = groupByFieldsAndValues;
        this.documentCount = documentCount;
    }

    public Map<String, Object> getGroupByFieldsAndValues() {
        return groupByFieldsAndValues;
    }

    public void setGroupByFieldsAndValues(Map<String, Object> groupByFieldsAndValues) {
        this.groupByFieldsAndValues = groupByFieldsAndValues;
    }

    public long getDocumentCount() {
        return documentCount;
    }

    public void setDocumentCount(long documentCount) {
        this.documentCount = documentCount;
    }

    @Override
    public String toString() {
        return "DocumentCountResponse{"
                + "groupByFieldsAndValues=" + groupByFieldsAndValues
                + ", documentCount=" + documentCount + '}';
    }
}
