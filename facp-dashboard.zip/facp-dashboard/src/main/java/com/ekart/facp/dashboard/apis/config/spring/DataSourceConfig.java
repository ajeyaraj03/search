package com.ekart.facp.dashboard.apis.config.spring;

import com.ekart.facp.dashboard.daos.repository.RecordRepositoryImpl;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.ImmutableSettings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.repository.config.EnableElasticsearchRepositories;

import javax.inject.Inject;
import java.util.List;

/**
 * Created by avinash.r on 15/04/16.
 */

@Configuration
@EnableElasticsearchRepositories(basePackages = "com.ekart.facp.dashboard.daos.repository")
public class DataSourceConfig {

    @Value("#{'${app.elasticsearch.hosts}'.split(',')}")
    private List<String> elasticsearchHosts;

    @Value("${app.elasticsearch.port}")
    private Integer elasticsearchPort;

    @Value("${app.elasticsearch.clusterName}")
    private String clusterName;

    @Inject
    private ObjectMapper objectMapper;

    @Bean
    public ElasticsearchTemplate elasticsearchTemplate() {

        ImmutableSettings.Builder settings = ImmutableSettings.settingsBuilder().
                put("cluster.name", clusterName).
                put("client.transport.sniff", true);
        TransportClient client = new TransportClient(settings);
        elasticsearchHosts
                .forEach((host) -> client.addTransportAddress(new InetSocketTransportAddress(host, elasticsearchPort)));
        return new ElasticsearchTemplate(client);
    }

    @Bean
    public RecordRepositoryImpl recordRepositoryImpl() {

        return new RecordRepositoryImpl(elasticsearchTemplate(), objectMapper);
    }
}
