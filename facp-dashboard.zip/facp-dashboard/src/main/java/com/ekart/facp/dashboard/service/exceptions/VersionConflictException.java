package com.ekart.facp.dashboard.service.exceptions;

import static com.ekart.facp.dashboard.service.utility.ErrorCode.VERSION_MISMATCHED;

/**
 * Created by avinash.r on 30/07/16.
 */
public class VersionConflictException extends BaseException {

    private static final long serialVersionUID = -7638828780013784505L;

    public VersionConflictException(long currentVersion, long providedVersion, Throwable cause) {
        super("Version mismatched current is : " + currentVersion + " and provided is : " + providedVersion,
                VERSION_MISMATCHED.name(), cause);
    }
}
