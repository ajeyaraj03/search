package com.ekart.facp.dashboard.daos.models;

/**
 * Created by avinash.r on 29/07/16.
 */
public class BulkRecord {

    private final String indexName;
    private final String typeName;
    private final long version;
    private final Record record;

    public BulkRecord(String indexName, String typeName, long version, Record record) {
        this.indexName = indexName;
        this.typeName = typeName;
        this.version = version;
        this.record = record;
    }

    public String getIndexName() {
        return indexName;
    }

    public String getTypeName() {
        return typeName;
    }

    public long getVersion() {
        return version;
    }

    public Record getRecord() {
        return record;
    }

    @Override
    public String toString() {
        return "BulkRecord{" + "indexName='" + indexName + '\''
                + ", typeName='" + typeName + '\'' + ", version=" + version + ", record=" + record + '}';
    }
}
