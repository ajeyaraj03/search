package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Map;

/**
 * Created by avinash.r on 21/04/16.
 */

@ApiModel
public class DocumentSearchResponse {

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "response", required = true)
    private List<Map<String, Object>> response;

    @ApiModelProperty
    @NotNull
    @JsonProperty(value = "total_count", required = true)
    private long totalCount;

    public DocumentSearchResponse() {

    }

    public DocumentSearchResponse(List<Map<String, Object>> response, long totalCount) {
        this.response = response;
        this.totalCount = totalCount;
    }

    public List<Map<String, Object>> getResponse() {
        return response;
    }

    public void setResponse(List<Map<String, Object>> response) {
        this.response = response;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    @Override
    public String toString() {
        return "DocumentSearchResponse{" + "response=" + response + ", totalCount=" + totalCount + '}';
    }
}
