package com.ekart.facp.dashboard.daos.repository;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.dashboard.daos.models.BulkRecord;
import com.ekart.facp.dashboard.daos.models.SearchResult;
import com.ekart.facp.dashboard.service.dtos.DocumentResult;
import com.ekart.facp.dashboard.service.exceptions.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.*;
import org.elasticsearch.indices.IndexMissingException;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.TermsBuilder;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.elasticsearch.ElasticsearchException;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.data.elasticsearch.core.query.IndexQueryBuilder;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.DEFAULT_PAGE;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.MAX_PAGE_SIZE;
import static com.ekart.facp.dashboard.service.utility.CommonHelper.withDocumentPrefix;
import static com.ekart.facp.dashboard.service.utility.Constants.CREATED_AT_EPOCH;
import static com.ekart.facp.dashboard.service.utility.EsErrorMessageParser.parseToDocumentResult;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;

/**
 * Created by avinash.r on 18/04/16.
 */

@ThreadSafe
@ParametersAreNonnullByDefault
public class RecordRepositoryImpl implements RecordRepository {

    private final ElasticsearchTemplate elasticsearchTemplate;
    private final ObjectMapper mapper;

    public RecordRepositoryImpl(ElasticsearchTemplate elasticsearchTemplate, ObjectMapper mapper) {

        this.elasticsearchTemplate = elasticsearchTemplate;
        this.mapper = mapper;
    }

    @Timed
    @ExceptionMetered
    @Override
    public void bulkInsert(List<BulkRecord> records) {
        try {
            elasticsearchTemplate.bulkIndex(prepareBulkQuery(records))

        } catch (JsonProcessingException e) {
            throw new InvalidInputException(e);

        } catch (ElasticsearchException e) {
            List<DocumentResult> documentResults = parseToDocumentResult(e.getFailedDocuments());
            if (!documentResults.isEmpty()) {
                //Document results will be empty if thrown exceptions is of type
                // VersionConflictEngineException with same version.
                throw new BatchProcessingException(documentResults);
            }
        }
    }

    @Timed
    @ExceptionMetered
    @Override
    public SearchResult search(String indexName, String typeName, final Map<String, Object> searchQueryParams,
                               Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt, int page) {
        //putting page-1 because elasticsearch start from page 0
        try {
            return elasticsearchTemplate.query(buildSearchQuery(searchQueryParams, fromCreatedAt, toCreatedAt)
                            .withIndices(indexName).withTypes(typeName)
                            .withPageable(new PageRequest(page - DEFAULT_PAGE, MAX_PAGE_SIZE)).build(),
                    SearchResult::getSearchResultFromResponse);

        } catch (IndexMissingException e) {
            throw new IndexNotFoundException(indexName, e);
        }
    }

    @Timed
    @ExceptionMetered
    @Override
    public Aggregations count(String indexName, String typeName, final Map<String, Object> searchQueryParams,
                              Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt,
                              final List<String> groupByFields) {

        try {
            return elasticsearchTemplate
                    .query(buildSearchQuery(searchQueryParams, fromCreatedAt, toCreatedAt)
                            .addAggregation(buildAggregationForCount(groupByFields))
                            .withIndices(indexName)
                            .withTypes(typeName).build(), SearchResponse::getAggregations);

        } catch (IndexMissingException e) {
            throw new IndexNotFoundException(indexName, e);
        }
    }

    private NativeSearchQueryBuilder buildSearchQuery(final Map<String, Object> searchQueryParams,
                                                      Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt) {
        BoolFilterBuilder boolFilterBuilder = null;

        if (!searchQueryParams.isEmpty()) {
            boolFilterBuilder = new BoolFilterBuilder();
            for (Map.Entry<String, Object> entry : searchQueryParams.entrySet()) {
                boolFilterBuilder = boolFilterBuilder.must(new TermFilterBuilder(
                        withDocumentPrefix(entry.getKey()), entry.getValue()));
            }
        }

        NativeSearchQueryBuilder queryBuilder = new NativeSearchQueryBuilder().
                withQuery(new FilteredQueryBuilder(buildRangeQuery(fromCreatedAt, toCreatedAt), boolFilterBuilder));
        return queryBuilder;
    }

    private QueryBuilder buildRangeQuery(Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt) {

        QueryBuilder queryBuilder = null;
        if (fromCreatedAt.isPresent() && toCreatedAt.isPresent()) {

            queryBuilder = QueryBuilders.rangeQuery(withDocumentPrefix(CREATED_AT_EPOCH))
                    .from(fromCreatedAt.get()).to(toCreatedAt.get());
        }
        return queryBuilder;
    }

    private TermsBuilder buildAggregationForCount(final List<String> groupByFields) {

        //generating the query for nested aggregation for multiple groupByFields by adding sub-aggregation to each term

        String lastGroupByField = groupByFields.get(groupByFields.size() - 1);

        //passing null in subAggregation will add null subAggregation and fail while building the search request,
        //with the exception SearchSourceBuilderException so adding first subAggregation explicitly.
        TermsBuilder aggregationQuery = terms(withDocumentPrefix(lastGroupByField))
                .field(withDocumentPrefix(lastGroupByField));

        for (int i = groupByFields.size() - 2; i >= 0; --i) {
            aggregationQuery = terms(withDocumentPrefix(groupByFields.get(i)))
                    .field(withDocumentPrefix(groupByFields.get(i))).subAggregation(aggregationQuery);
        }
        return aggregationQuery;
    }

    private List<IndexQuery> prepareBulkQuery(List<BulkRecord> records) throws JsonProcessingException {

        List<IndexQuery> bulkQuery = Lists.newArrayListWithExpectedSize(records.size());
        for (BulkRecord record : records) {
            bulkQuery.add(
                    new IndexQueryBuilder().withIndexName(record.getIndexName()).withType(record.getTypeName())
                            .withId(record.getRecord().getId()).withVersion(record.getVersion())
                            .withSource(mapper.writeValueAsString(record.getRecord())).build()
            );
        }
        return bulkQuery;
    }
}
