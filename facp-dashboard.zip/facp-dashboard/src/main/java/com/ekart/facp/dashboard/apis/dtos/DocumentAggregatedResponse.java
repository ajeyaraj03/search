package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * Created by avinash.r on 21/04/16.
 */
@ApiModel
public class DocumentAggregatedResponse {

    @ApiModelProperty(name = "aggregations", value = "Aggregated count documents")
    @NotNull
    @JsonProperty(value = "aggregations", required = true)
    private List<DocumentCountResponse> aggregations;

    public DocumentAggregatedResponse() {
    }

    public DocumentAggregatedResponse(List<DocumentCountResponse> aggregations) {
        this.aggregations = aggregations;
    }

    public List<DocumentCountResponse> getAggregations() {
        return aggregations;
    }

    public void setAggregations(List<DocumentCountResponse> aggregations) {
        this.aggregations = aggregations;
    }

    @Override
    public String toString() {
        return "DocumentAggregatedResponseList{"
                + "aggregations=" + aggregations + '}';
    }
}
