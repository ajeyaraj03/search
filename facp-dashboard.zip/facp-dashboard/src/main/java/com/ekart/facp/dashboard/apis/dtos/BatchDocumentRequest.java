package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.Valid;
import javax.validation.constraints.Size;
import java.util.List;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;

/**
 * Created by ajeya.hb on 18/06/16.
 */
@ApiModel
public class BatchDocumentRequest {

    @ApiModelProperty(name = "document_requests", value = "Documents to be inserted")
    @JsonProperty(value = "document_requests", required = true)
    @NotEmpty(message = "{document.documentRequests.notempty}")
    @Valid
    @Size(max = MAX_DOCUMENTS, message = "{document.documentRequests.size}")
    private List<DocumentRequest> documentRequests;

    public List<DocumentRequest> getDocumentRequests() {
        return documentRequests;
    }

    public void setDocumentRequests(List<DocumentRequest> documentRequests) {
        this.documentRequests = documentRequests;
    }

    @Override
    public String toString() {
        return "BatchDocumentRequest{"
                + "documentRequests=" + documentRequests.toString()
                + '}';
    }
}
