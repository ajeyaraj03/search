package com.ekart.facp.dashboard.service.exceptions;

/**
 * Created by ajeya.hb on 05/07/16.
 */

import static com.ekart.facp.dashboard.service.utility.ErrorCode.BATCH_PROCESSING_FAILED;

public class BatchProcessingException extends BaseException {

    private static final long serialVersionUID = 7652667516782745129L;

    public BatchProcessingException(Object response) {

        super("Failed to Process Batch Items", BATCH_PROCESSING_FAILED.name(), response);
    }

}
