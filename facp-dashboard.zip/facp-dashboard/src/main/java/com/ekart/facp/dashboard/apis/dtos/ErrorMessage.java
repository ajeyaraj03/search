/**
 *
 */
package com.ekart.facp.dashboard.apis.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

import javax.annotation.ParametersAreNonnullByDefault;

/**
 * @author vijay.daniel
 */
@ApiModel(value = "error_message", description = "Error message when there is a failure to process the request")
@ParametersAreNonnullByDefault
public class ErrorMessage<T> {

    @ApiModelProperty(name = "message", value = "An error message containing the reason for the failure",
            required = true)
    @JsonProperty("message")
    private String message;

    @ApiModelProperty(name = "error_code", value = "An error code for the failure")
    @JsonProperty("error_code")
    private String errorCode;

    @ApiModelProperty(name = "response", value = "Error response Object")
    @JsonProperty("response")
    private T response;

    public ErrorMessage(String message, String errorCode) {

        this.message = message;
        this.errorCode = errorCode;
    }

    @JsonCreator
    public ErrorMessage(@JsonProperty("message") String message, @JsonProperty("error_code") String errorCode,
                        @JsonProperty("response") T response) {

        this.message = message;
        this.errorCode = errorCode;
        this.response = response;
    }

    public String getMessage() {

        return message;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public Object getResponse() {
        return response;
    }

    @Override
    public String toString() {
        return "ErrorMessage{"
                + "message='" + message + '\''
                + ", errorCode='" + errorCode + '\''
                + ", response=" + response + '}';
    }
}
