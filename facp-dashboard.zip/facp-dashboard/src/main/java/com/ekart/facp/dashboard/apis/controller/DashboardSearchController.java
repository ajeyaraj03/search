package com.ekart.facp.dashboard.apis.controller;

import com.codahale.metrics.annotation.ExceptionMetered;
import com.codahale.metrics.annotation.Timed;
import com.ekart.facp.dashboard.apis.dtos.DocumentAggregatedResponse;
import com.ekart.facp.dashboard.apis.dtos.DocumentAggregationRequest;
import com.ekart.facp.dashboard.apis.dtos.DocumentSearchResponse;
import com.ekart.facp.dashboard.apis.dtos.ErrorMessage;
import com.ekart.facp.dashboard.apis.mappers.ApiDtoToServiceDtoMapper;
import com.ekart.facp.dashboard.service.DashboardService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.eclipse.jetty.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.annotation.ParametersAreNonnullByDefault;
import javax.annotation.concurrent.ThreadSafe;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.MediaType;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.CLIENT_KEY;
import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.TENANT_KEY;
import static com.ekart.facp.dashboard.apis.util.ApiUtil.tenantContext;
import static com.ekart.facp.dashboard.service.utility.Constants.*;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by avinash.r on 16/05/16.
 */

@Api(protocols = "http")
@ThreadSafe
@RestController
@RequestMapping("/api/v1/opsearch/document/search")
@ParametersAreNonnullByDefault
public class DashboardSearchController extends BaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(DashboardSearchController.class);

    private final DashboardService dashboardService;
    private final ApiDtoToServiceDtoMapper mapper;

    public DashboardSearchController(DashboardService dashboardService, ApiDtoToServiceDtoMapper mapper) {

        checkNotNull(dashboardService);
        checkNotNull(mapper);
        this.dashboardService = dashboardService;
        this.mapper = mapper;
    }

    @ApiOperation(nickname = "search", value = "Search the document in elastic search based on provided filters",
            notes = "Response is list of documents")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200,
                    message = "Documents retrieved successfully", response = DocumentSearchResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Mandatory params are not present.", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred", response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(value = "/{name}/{type}/", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<DocumentSearchResponse> search(
            @PathVariable @Valid @NotNull String name,
            @PathVariable @Valid @NotNull String type,
            @RequestParam(value = PAGE, required = false) int page,
            @RequestParam Map<String, Object> queryParams,
            @RequestHeader(value = CLIENT_KEY, required = false) String client,
            @RequestHeader(value = TENANT_KEY, required = false) String tenant) {

        LOGGER.trace("Searching for client : {} name : {} and type: {}", client, name, type);
        return ok(mapper.serviceSearchResponseToApiResponse(dashboardService.search(
                tenantContext(tenant), name, type, queryParams, Optional.empty(), Optional.empty(),
                Optional.ofNullable(page))));
    }

    @ApiOperation(nickname = "range_search",
            value = "Search the document in elastic search based on provided filters and time range params",
            notes = "Response is list of documents")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200,
                    message = "Documents retrieved successfully", response = DocumentSearchResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Mandatory params are not present.", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred", response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(value = "/{name}/{type}/range/", method = RequestMethod.GET,
            produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<DocumentSearchResponse> searchWithRange(
            @PathVariable @Valid @NotNull String name,
            @PathVariable @Valid @NotNull String type,
            @RequestParam(value = FROM_CREATED_AT) @NotNull Long fromCreatedAt,
            @RequestParam(value = TO_CREATED_AT) @NotNull Long toCreatedAt,
            @RequestParam(value = PAGE, required = false) Integer page,
            @RequestParam Map<String, Object> queryParams,
            @RequestHeader(value = CLIENT_KEY, required = false) String client,
            @RequestHeader(value = TENANT_KEY, required = false) String tenant) {

        LOGGER.trace("Searching with range for client : {} name : {} and type: {}", client, name, type);
        return ok(mapper.serviceSearchResponseToApiResponse(dashboardService.search(
                tenantContext(tenant), name, type, queryParams, Optional.of(fromCreatedAt), Optional.of(toCreatedAt),
                Optional.ofNullable(page))));
    }

    @ApiOperation(nickname = "count", value = "Count the document in elastic search based on provided filters",
            notes = "Response is different status with their document count")
    @ApiResponses({
            @ApiResponse(code = HttpStatus.OK_200,
                    message = "Documents retrieved successfully", response = DocumentAggregatedResponse.class),
            @ApiResponse(code = HttpStatus.BAD_REQUEST_400,
                    message = "Mandatory params are not present.", response = ErrorMessage.class),
            @ApiResponse(code = HttpStatus.INTERNAL_SERVER_ERROR_500,
                    message = "Internal server error. An unexpected error occurred", response = ErrorMessage.class)})
    @Timed
    @ExceptionMetered
    @RequestMapping(value = "/{name}/{type}/aggregates/count/", method = RequestMethod.POST,
            produces = MediaType.APPLICATION_JSON)
    public ResponseEntity<DocumentAggregatedResponse> count(
            @PathVariable @Valid @NotNull String name,
            @PathVariable @Valid @NotNull String type,
            @RequestBody @Validated DocumentAggregationRequest request,
            @RequestHeader(value = CLIENT_KEY, required = false) String client,
            @RequestHeader(value = TENANT_KEY, required = false) String tenant) {

        LOGGER.trace("Counting for client: {} name : {} and type: {}", client, name, type);

        List<com.ekart.facp.dashboard.service.dtos.DocumentCountResponse> response = dashboardService.count(
                tenantContext(tenant), name, type, request.getQueryParams(),
                Optional.ofNullable(request.getFromCreatedAt()),
                Optional.ofNullable(request.getToCreatedAt()), request.getGroupByFields());
        return ok(new DocumentAggregatedResponse(response.stream().map(
                elt -> mapper.serviceCountResponseToApiResponse(elt)).collect(Collectors.toList())));
    }
}
