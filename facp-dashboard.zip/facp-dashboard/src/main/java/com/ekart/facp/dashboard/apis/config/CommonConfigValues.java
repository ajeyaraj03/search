package com.ekart.facp.dashboard.apis.config;

/**
 * Created by avinash.r on 18/05/16.
 */
public final class CommonConfigValues {

    public static final int MAX_GROUP_BY_FIELDS = 5;
    public static final int MAX_PAGE_SIZE = 20;
    public static final int DEFAULT_PAGE = 1;
    public static final int MAX_DOCUMENTS = 5000;
    public static final String CLIENT_KEY = "X-Ekart-Client";
    //Update the Tenant key once its finalized
    public static final String TENANT_KEY = "";
}
