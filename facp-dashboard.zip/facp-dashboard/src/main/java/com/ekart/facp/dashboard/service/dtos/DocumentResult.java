package com.ekart.facp.dashboard.service.dtos;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import javax.annotation.concurrent.Immutable;

/**
 * Created by ajeya.hb on 19/06/16.
 */
@Immutable
public final class DocumentResult {
    private final String name;
    private final String type;
    private final String id;
    private final boolean success;
    private final String message;

    @JsonCreator
    public DocumentResult(@JsonProperty("name") String name, @JsonProperty("type") String type,
                          @JsonProperty("id") String id, @JsonProperty("success") boolean success,
                          @JsonProperty("message") String message) {
        this.name = name;
        this.type = type;
        this.id = id;
        this.success = success;
        this.message = message;
    }


    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public String getId() {
        return id;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return "DocumentResult{" + "name='" + name + '\'' + ", type='" + type + '\''
                + ", id='" + id + '\'' + ", success=" + success + ", message='" + message + '\'' + '}';
    }
}
