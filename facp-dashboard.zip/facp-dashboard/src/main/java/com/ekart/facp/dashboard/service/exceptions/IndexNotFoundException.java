package com.ekart.facp.dashboard.service.exceptions;

/**
 * Created by avinash.r on 02/06/16.
 */

import static com.ekart.facp.dashboard.service.utility.ErrorCode.INDEX_NOT_FOUND;

public class IndexNotFoundException extends BaseException {

    private static final long serialVersionUID = 8803955692990773981L;

    public IndexNotFoundException(String indexName, Throwable cause) {
        super("No index found with : " + indexName, INDEX_NOT_FOUND.name(), cause);
    }
}
