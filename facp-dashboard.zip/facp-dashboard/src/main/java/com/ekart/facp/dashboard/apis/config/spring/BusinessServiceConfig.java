package com.ekart.facp.dashboard.apis.config.spring;

import com.ekart.facp.dashboard.daos.repository.RecordRepository;
import com.ekart.facp.dashboard.service.DashboardService;
import com.ekart.facp.dashboard.service.DashboardServiceImpl;
import com.ekart.facp.dashboard.service.mapper.MapToRecordMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.inject.Inject;

/**
 * Created by avinash.r on 24/05/16.
 */
@Configuration
public class BusinessServiceConfig {

    @Inject
    private RecordRepository recordRepository;

    @Inject
    private MapToRecordMapper mapToRecordMapper;

    @Bean
    public DashboardService dashboardService() {

        return new DashboardServiceImpl(recordRepository, mapToRecordMapper);
    }
}
