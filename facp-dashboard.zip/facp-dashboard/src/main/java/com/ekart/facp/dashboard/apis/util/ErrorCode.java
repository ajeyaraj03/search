package com.ekart.facp.dashboard.apis.util;

/**
 * Created by ajeya.hb on 06/07/16.
 */
public enum ErrorCode {
    VALIDATION_ERROR,
    UNKNOWN_ERROR
}
