package com.ekart.facp.dashboard.service.exceptions;

/**
 * Created by avinash.r on 20/04/16.
 */
public abstract class BaseException extends RuntimeException {

    private static final long serialVersionUID = -3974175123412894944L;
    private final String errorCode;
    private Object response;

    protected BaseException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }

    protected BaseException(String message, String errorCode, Object response) {
        super(message);
        this.errorCode = errorCode;
        this.response = response;
    }

    protected BaseException(String message, String errorCode, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
    }

    protected BaseException(String message, String errorCode, Object response, Throwable cause) {
        super(message, cause);
        this.errorCode = errorCode;
        this.response = response;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public Object getResponse() {
        return response;
    }
}
