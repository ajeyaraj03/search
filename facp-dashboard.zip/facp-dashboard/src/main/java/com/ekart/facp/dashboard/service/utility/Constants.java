package com.ekart.facp.dashboard.service.utility;

/**
 * Created by avinash.r on 05/05/16.
 */
public final class Constants {

    public static final String DATA = "data";
    public static final String FROM_CREATED_AT = "fromCreatedAt";
    public static final String TO_CREATED_AT = "toCreatedAt";
    public static final String CREATED_AT_EPOCH = "createdAtEpoch";
    public static final String UPDATED_AT_EPOCH = "updatedAtEpoch";
    public static final String DOCUMENT_PREFIX = DATA + ".";
    public static final String PAGE = "page";
}
