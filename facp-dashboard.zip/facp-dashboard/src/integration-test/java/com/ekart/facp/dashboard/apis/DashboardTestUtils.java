package com.ekart.facp.dashboard.apis;

import com.ekart.facp.dashboard.apis.dtos.*;
import com.ekart.facp.dashboard.service.dtos.DocumentResult;
import com.google.common.collect.Lists;
import org.hamcrest.Matchers;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.ekart.facp.dashboard.service.utility.Constants.*;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.core.Is.is;

/**
 * Created by avinash.r on 16/05/16.
 */
public final class DashboardTestUtils {

    public static final String NAME = "test_index";
    public static final String TYPE = "test_type";
    public static final String ATTRIBUTE_KEY = "attributeKey";
    public static final int SINGLE_INDEX = 1;
    public static final String NESTED_KEY = "nestedKey.attributeKey";
    //setting DELTA_MILLI_SECONDS = 1 hour
    public static final long DELTA_MILLI_SECONDS = 3600000L;
    //default refresh interval is 1 second need to change it when refresh interval is changed
    public static final long SLEEP_TIME = 2000L;


    public static BatchDocumentRequest createBatchDocumentRequestForSingleIndex(String name, String type, String id,
                                                                                long createdAt, long updatedAt,
                                                                                Map<String, Object> fieldMapPairIndex) {
        BatchDocumentRequest batchDocumentRequest = new BatchDocumentRequest();
        batchDocumentRequest.setDocumentRequests(Lists.newArrayList(
                createRecordRequest(name, type, id, createdAt, updatedAt, fieldMapPairIndex,
                        SINGLE_INDEX)));
        return batchDocumentRequest;
    }

    public static BatchDocumentRequest createBatchDocumentRequestForMultipleIndex(int noOfIndex) {
        BatchDocumentRequest batchDocumentRequest = new BatchDocumentRequest();
        String randomKey = randomAlphabetic(20);
        String randomValue = randomAlphabetic(20);
        long currentTime = System.currentTimeMillis();
        List<DocumentRequest> docRequests = Lists.newArrayListWithExpectedSize(noOfIndex);
        for (int docNum = 1; docNum <= noOfIndex; docNum++) {
            Map<String, Object> fieldMapPairIndex = new HashMap<>();
            fieldMapPairIndex.put(randomKey, randomValue);
            docRequests.add(createRecordRequest(NAME, TYPE, randomAlphabetic(20), currentTime,
                    currentTime, fieldMapPairIndex, docNum));
        }
        batchDocumentRequest.setDocumentRequests(docRequests);
        return batchDocumentRequest;
    }


    private static DocumentRequest createRecordRequest(String name, String type, String id,
                                                       long createdAt, long updatedAt,
                                                       Map<String, Object> fieldMapPairIndex,
                                                       int version) {
        DocumentRequest documentRequest = new DocumentRequest();
        documentRequest.setFieldMapPair(fieldMapPairIndex);
        documentRequest.setCreatedAtEpoch(createdAt);
        documentRequest.setUpdatedAtEpoch(updatedAt);
        documentRequest.setId(id);
        documentRequest.setName(name);
        documentRequest.setType(type);
        documentRequest.setVersion(version);
        return documentRequest;
    }

    public static List<DocumentResult> getBatchDocumentResults(List<DocumentRequest> documentRequests) {
        return documentRequests.stream().map(doc -> new DocumentResult(doc.getName(), doc.getType(),
                doc.getId(), false, null)).collect(Collectors.toList());
    }

    public static Map<String, Object> prepareSearchRequest(long fromCreatedAt, long toCreatedAt,
                                                           Map<String, Object> attributes) {

        Map<String, Object> params = new HashMap<>();
        params.put(FROM_CREATED_AT, fromCreatedAt);
        params.put(TO_CREATED_AT, toCreatedAt);
        for (Map.Entry<String, Object> entry : attributes.entrySet()) {
            params.put(entry.getKey(), entry.getValue());
        }
        return params;
    }

    public static DocumentAggregationRequest prepareCountRequest(Long fromCreatedAt,
                                                                 Long toCreatedAt, Map<String, Object> params) {

        DocumentAggregationRequest aggregationRequest = new DocumentAggregationRequest();
        aggregationRequest.setQueryParams(params);
        aggregationRequest.setGroupByFields(Lists.newArrayList(ATTRIBUTE_KEY));
        aggregationRequest.setFromCreatedAt(fromCreatedAt);
        aggregationRequest.setToCreatedAt(toCreatedAt);
        return aggregationRequest;
    }

    public static DocumentSearchResponse getExpectedSearchResponse(List<DocumentRequest> documentRequests) {

        List<Map<String, Object>> response = Lists.newArrayListWithExpectedSize(documentRequests.size());
        for (DocumentRequest documentRequest : documentRequests) {
            documentRequest.getFieldMapPair().put(CREATED_AT_EPOCH, documentRequest.getCreatedAtEpoch());
            documentRequest.getFieldMapPair().put(UPDATED_AT_EPOCH, documentRequest.getUpdatedAtEpoch());
            response.add(documentRequest.getFieldMapPair());
        }
        return new DocumentSearchResponse(response, documentRequests.size());
    }

    public static void assertEmptyCountResponse(ResponseEntity<DocumentAggregatedResponse> actualCountResponse) {

        assertThat(actualCountResponse.getStatusCode(), Matchers.is(HttpStatus.OK));
        assertThat(actualCountResponse.getBody().getAggregations().size(), is(0));
    }

    public static void assertEmptySearchResponse(ResponseEntity<DocumentSearchResponse> actualSearchResponse) {

        assertThat(actualSearchResponse.getStatusCode(), Matchers.is(HttpStatus.OK));
        assertThat(actualSearchResponse.getBody().getResponse().size(), is(0));
    }

    public static void sortAggregations(List<DocumentCountResponse> aggregations, String key) {

        aggregations.sort((r1, r2) -> r1.getGroupByFieldsAndValues().get(key).toString().compareTo(
                r2.getGroupByFieldsAndValues().get(key).toString()));
    }

    //public static void sortRecords()
}
