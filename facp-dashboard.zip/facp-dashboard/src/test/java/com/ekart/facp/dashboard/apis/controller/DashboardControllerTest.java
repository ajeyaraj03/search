package com.ekart.facp.dashboard.apis.controller;

import com.ekart.facp.dashboard.apis.dtos.BatchDocumentRequest;
import com.ekart.facp.dashboard.apis.dtos.SuccessResponse;
import com.ekart.facp.dashboard.apis.mappers.ApiDtoToServiceDtoMapper;
import com.ekart.facp.dashboard.apis.util.TenantContext;
import com.ekart.facp.dashboard.service.DashboardService;
import com.ekart.facp.dashboard.service.dtos.BatchDocument;
import org.hamcrest.Matchers;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.io.IOException;

import static com.google.common.base.Preconditions.checkNotNull;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by avinash.r on 06/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class DashboardControllerTest {

    @Mock
    private DashboardService dashboardService;

    private DashboardController dashboardController;

    @Mock
    private ApiDtoToServiceDtoMapper apiDtoToServiceDtoMapper;

    @Mock
    private BatchDocument batchDocument;

    @Mock
    private BatchDocumentRequest batchDocumentRequest;

    @Mock
    private TenantContext tenantContext;

    public static <T> void assertResponse(ResponseEntity<T> actualResponse, HttpStatus expectedStatus,
                                          Object expectedBody) {
        assertThat(actualResponse.getStatusCode(), is(expectedStatus));
        assertReflectionEquals(actualResponse.getBody(), expectedBody);
    }

    protected static void assertCreated(ResponseEntity<?> response) {

        assertThat(response.getStatusCode(), Matchers.is(HttpStatus.CREATED));
    }

    @Before
    public void setup() {

        dashboardController = new DashboardController(dashboardService, apiDtoToServiceDtoMapper);
        checkNotNull(dashboardController);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionWhileIndexingIfDashboardServiceIsNull() {
        new DashboardController(null, null);
    }

    @Test
    public void shouldIndexDocumentBasedOnInsertParams() throws IOException {
        when(apiDtoToServiceDtoMapper.batchDocumentRequestTobatchDocument(batchDocumentRequest))
                .thenReturn(batchDocument);
        ResponseEntity<SuccessResponse> successResponse = dashboardController
                .indexDocument(batchDocumentRequest, "client", "tenant");

        verify(dashboardService, times(1)).bulkCreate(tenantContext, batchDocument.getDocuments());
        assertCreated(successResponse);
    }
}
