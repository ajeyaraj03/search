package com.ekart.facp.dashboard.daos.models;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.Map;

import static com.ekart.facp.dashboard.service.utility.Constants.DATA;
import static org.mockito.Mockito.when;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by avinash.r on 13/06/16.
 */
@RunWith(MockitoJUnitRunner.class)
public class SearchResultTest {

    @Mock
    private SearchResponse response;

    @Mock
    private SearchHit searchHit;

    @Mock
    private SearchHits searchHits;

    @Mock
    private Map<String, Object> data;

    @Test
    public void shouldReturnSearchResult() {

        Map<String, Object> source = ImmutableMap.of(DATA, data);
        SearchHit[] hits = {searchHit};
        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(new Record("id", data)), 1L);

        when(response.getHits()).thenReturn(searchHits);
        when(searchHits.getHits()).thenReturn(hits);
        when(searchHit.getId()).thenReturn("id");
        when(searchHit.getSource()).thenReturn(source);
        when(searchHits.getTotalHits()).thenReturn(1L);

        assertReflectionEquals(SearchResult.getSearchResultFromResponse(response), expectedResponse);
    }
}
