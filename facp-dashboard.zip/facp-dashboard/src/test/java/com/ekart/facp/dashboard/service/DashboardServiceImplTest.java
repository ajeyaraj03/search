package com.ekart.facp.dashboard.service;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;
import com.ekart.facp.dashboard.apis.util.TenantContext;
import com.ekart.facp.dashboard.daos.models.BulkRecord;
import com.ekart.facp.dashboard.daos.models.Record;
import com.ekart.facp.dashboard.daos.models.SearchResult;
import com.ekart.facp.dashboard.daos.repository.RecordRepository;
import com.ekart.facp.dashboard.service.dtos.*;
import com.ekart.facp.dashboard.service.mapper.MapToRecordMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.ekart.facp.dashboard.DashboardTestUtils.createRecord;
import static com.ekart.facp.dashboard.DashboardTestUtils.generateId;
import static com.ekart.facp.dashboard.service.utility.CommonHelper.withDocumentPrefix;
import static com.ekart.facp.dashboard.service.utility.Constants.CREATED_AT_EPOCH;
import static com.ekart.facp.dashboard.service.utility.Constants.UPDATED_AT_EPOCH;
import static org.apache.commons.lang.RandomStringUtils.randomAlphabetic;
import static org.mockito.Mockito.*;
import static org.unitils.reflectionassert.ReflectionAssert.assertReflectionEquals;

/**
 * Created by avinash.r on 05/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class DashboardServiceImplTest {

    private static final String NAME = "inventory";
    private static final String TYPE = "type";
    private static final String ID = "id";
    private static final String ATTRIBUTE_KEY = "attributeKey";
    private static final long CURRENT_TIME = 1L;
    private static final long VERSION = 1;

    @Mock
    private RecordRepository recordRepository;

    @Mock
    private MapToRecordMapper mapper;

    @Mock
    private Aggregations aggregations;

    @Mock
    private Terms aggregationTerms;

    @Mock
    private Terms.Bucket bucket;

    @Mock
    private Map<String, Object> searchParams;

    @Mock
    private TenantContext tenantContext;

    private Record record;

    private DashboardServiceImpl dashboardService;

    @Before
    public void setup() {

        dashboardService = new DashboardServiceImpl(recordRepository, mapper);
        record = createNewRecord();
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfRecordRepositoryIsNull() {
        new DashboardServiceImpl(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfMapperIsNull() {
        new DashboardServiceImpl(recordRepository, null);
    }

    @Test
    public void shouldCreateSingleIndex() {

        List<Document> documents = createBatchDocument(1);
        /**document 1 expectations */
        Document document1 = documents.get(0);
        Map<String, Object> expectedInsertArg1 = document1.getParams();
        expectedInsertArg1.put(CREATED_AT_EPOCH, document1.getCreatedAtEpoch());
        expectedInsertArg1.put(UPDATED_AT_EPOCH, document1.getUpdatedAtEpoch());

        when(mapper.mapToRecord(generateId(document1.getType(), document1.getId()), expectedInsertArg1))
                .thenReturn(record);

        dashboardService.bulkCreate(tenantContext, documents);
        verify(recordRepository, times(1)).bulkInsert(refEq(Lists.newArrayList(new BulkRecord(document1.getName(),
                document1.getType(), document1.getVersion(), record))));
    }

    @Test
    public void shouldCreateMultipleIndexDocuments() {

        List<Document> documents = createBatchDocument(3);
        /**document 1 expectations */
        Document document1 = documents.get(0);
        Map<String, Object> expectedInsertArg1 = document1.getParams();
        expectedInsertArg1.put(CREATED_AT_EPOCH, document1.getCreatedAtEpoch());
        expectedInsertArg1.put(UPDATED_AT_EPOCH, document1.getUpdatedAtEpoch());

        when(mapper.mapToRecord(generateId(document1.getType(), document1.getId()), expectedInsertArg1))
                .thenReturn(record);

        /**document 2 expectations */
        Document document2 = documents.get(1);
        Map<String, Object> expectedInsertArg2 = document2.getParams();
        expectedInsertArg2.put(CREATED_AT_EPOCH, document2.getCreatedAtEpoch());
        expectedInsertArg2.put(UPDATED_AT_EPOCH, document2.getUpdatedAtEpoch());

        when(mapper.mapToRecord(generateId(document2.getType(), document2.getId()), expectedInsertArg2))
                .thenReturn(record);

        /**document 3 expectations */
        Document document3 = documents.get(2);
        Map<String, Object> expectedInsertArg3 = document3.getParams();
        expectedInsertArg3.put(CREATED_AT_EPOCH, document3.getCreatedAtEpoch());
        expectedInsertArg3.put(UPDATED_AT_EPOCH, document3.getUpdatedAtEpoch());

        when(mapper.mapToRecord(generateId(document3.getType(), document3.getId()), expectedInsertArg3))
                .thenReturn(record);
        dashboardService.bulkCreate(tenantContext, documents);
        verify(recordRepository, times(1)).bulkInsert(refEq(Lists.newArrayList(
                new BulkRecord(document1.getName(), document1.getType(), document1.getVersion(), record),
                new BulkRecord(document2.getName(), document2.getType(), document2.getVersion(), record),
                new BulkRecord(document3.getName(), document3.getType(), document3.getVersion(), record))));
    }

    @Test
    public void shouldReturnDocumentsBasedOnSearchParams() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(recordRepository.search(NAME, TYPE, searchParams, currentTime, currentTime, DEFAULT_PAGE))
                .thenReturn(expectedResponse);

        DocumentSearchResponse response = dashboardService.search(tenantContext, NAME, TYPE, searchParams,
                currentTime, currentTime, Optional.empty());
        assertReflectionEquals(response, new DocumentSearchResponse(expectedResponse.getRecords().stream().map(
                elt -> elt.getData()).collect(Collectors.toList()), 1));
    }

    @Test
    public void shouldReturnDocumentsBasedOnSearchParamsWithRange() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(recordRepository.search(NAME, TYPE, searchParams, currentTime, currentTime, 2))
                .thenReturn(expectedResponse);

        DocumentSearchResponse response = dashboardService.search(tenantContext, NAME, TYPE, searchParams,
                currentTime, currentTime, Optional.of(2));
        assertReflectionEquals(response, new DocumentSearchResponse(expectedResponse.getRecords().stream().map(
                elt -> elt.getData()).collect(Collectors.toList()), 1));
    }

    @Test
    public void shouldReturnAggregatedResultsBasedOnSearchParams() {

        List<String> groupByFields = Lists.newArrayList("attributeKey", "appId");
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);

        when(recordRepository.count(NAME, TYPE, searchParams, currentTime, currentTime, groupByFields))
                .thenReturn(aggregations);
        when(aggregations.get(withDocumentPrefix("attributeKey"))).thenReturn(aggregationTerms);
        when(aggregations.get(withDocumentPrefix("appId"))).thenReturn(aggregationTerms);
        when(bucket.getKey()).thenReturn("attributeValue");
        when(bucket.getDocCount()).thenReturn(1L);
        when(bucket.getAggregations()).thenReturn(aggregations);
        when(aggregationTerms.getBuckets()).thenReturn(Lists.newArrayList(bucket));

        List<DocumentCountResponse> response = dashboardService.count(tenantContext, NAME, TYPE, searchParams,
                currentTime, currentTime, groupByFields);
        List<DocumentCountResponse> expectedResponse = Lists.newArrayList(new DocumentCountResponse(
                ImmutableMap.of(ATTRIBUTE_KEY, "attributeValue", "appId", "attributeValue"), 1L));
        assertReflectionEquals(response, expectedResponse);
    }

    private Record createNewRecord() {
        Map<String, Object> insertParams = getParamsMap();
        return createRecord(insertParams, generateId(TYPE, ID));
    }

    private Map<String, Object> getParamsMap() {
        Map<String, Object> expectedInsertArg = new HashMap<>();
        expectedInsertArg.put(ATTRIBUTE_KEY, "attributeValue");
        return expectedInsertArg;
    }

    private List<Document> createBatchDocument(int noOfDocs) {
        List<Document> docs = Lists.newArrayListWithExpectedSize(noOfDocs);
        for (int docNum = 1; docNum <= noOfDocs; docNum++) {
            Map<String, Object> expectedInsertArg = new HashMap<>();
            expectedInsertArg.put(randomAlphabetic(20), randomAlphabetic(20));
            Document document = new Document();
            document.setType(randomAlphabetic(20));
            document.setId(randomAlphabetic(20));
            document.setName(randomAlphabetic(20));
            document.setParams(expectedInsertArg);
            document.setVersion(VERSION);
            document.setCreatedAtEpoch(CURRENT_TIME);
            document.setUpdatedAtEpoch(CURRENT_TIME);
            docs.add(document);
        }
        return docs;
    }

}
