package com.ekart.facp.dashboard.apis.controller;

import com.ekart.facp.dashboard.apis.dtos.DocumentAggregatedResponse;
import com.ekart.facp.dashboard.apis.dtos.DocumentAggregationRequest;
import com.ekart.facp.dashboard.apis.dtos.DocumentSearchResponse;
import com.ekart.facp.dashboard.apis.mappers.ApiDtoToServiceDtoMapper;
import com.ekart.facp.dashboard.apis.util.TenantContext;
import com.ekart.facp.dashboard.service.DashboardService;
import com.ekart.facp.dashboard.service.dtos.DocumentCountResponse;
import static com.ekart.facp.dashboard.service.utility.Constants.*;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.ekart.facp.dashboard.apis.controller.DashboardControllerTest.assertResponse;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.when;

/**
 * Created by avinash.r on 06/05/16.
 */

@RunWith(MockitoJUnitRunner.class)
public class DashboardSearchControllerTest {

    private static final String NAME = "inventory";
    private static final String TYPE = "type";
    private static final String CLIENT_KEY = "client";
    private static final String TENANT_KEY = "tenantContext";
    private static final Integer PAGE_NUMBER = 2;
    private static final long CURRENT_TIME = 1L;

    @Mock
    private DashboardService dashboardService;

    @Mock
    private ApiDtoToServiceDtoMapper mapper;

    private DashboardSearchController dashboardSearchController;

    @Mock
    private Map<String, Object> fieldMapPair;

    @Mock
    private DocumentCountResponse countResult;

    @Mock
    private com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse searchResponse;

    @Mock
    private com.ekart.facp.dashboard.apis.dtos.DocumentCountResponse countApiResult;

    @Mock
    private Terms.Bucket bucket;

    private TenantContext tenantContext;

    @Before
    public void setup() {

        dashboardSearchController = new DashboardSearchController(dashboardService, mapper);
        tenantContext = new TenantContext();
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfDashboardServiceIsNull() {

        new DashboardSearchController(null, mapper);
    }

    @Test(expected = NullPointerException.class)
    public void shouldRaiseExceptionIfMapperIsNull() {

        new DashboardSearchController(dashboardService, null);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearching() {

        Map<String, Object> request = createSearchRequest();
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.empty())))
                .thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE,
                null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearching() {

        Map<String, Object> request = createSearchRequest();
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 0);
        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.empty())))
                .thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);

        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE,
                null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearchingForNestedDocument() {

        Map<String, Object> request = createNestedDocumentSearchRequest();
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.empty())))
                .thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE,
                null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearchingForNestedDocument() {

        Map<String, Object> request = createNestedDocumentSearchRequest();
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 0);
        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.empty())))
                .thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);

        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE, null,
                request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearchingWithPage() {

        Map<String, Object> request = createSearchRequest();
        request.put(PAGE, PAGE_NUMBER);
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.of(PAGE_NUMBER))))
                .thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE,
                PAGE_NUMBER, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearchingWithPage() {

        Map<String, Object> request = createSearchRequest();
        request.put(PAGE, PAGE_NUMBER);
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 0);
        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.empty()), eq(Optional.empty()), eq(Optional.of(PAGE_NUMBER))))
                .thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);

        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.search(NAME, TYPE,
                PAGE_NUMBER, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearchingWithRange() {

        Map<String, Object> request = createSearchRequest();
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME), eq(TYPE), eq(request),
                eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)), eq(Optional.empty())))
                .thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearchingWithRange() {

        Map<String, Object> request = createSearchRequest();
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 0);
        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)),
                eq(Optional.empty()))).thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearchingForNestedDocumentWithRange() {

        Map<String, Object> request = createNestedDocumentSearchRequest();
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)),
                eq(Optional.empty()))).thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);

        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearchingForNestedDocumentWithRange() {

        Map<String, Object> request = createNestedDocumentSearchRequest();
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 1);

        when(dashboardService.search(any(TenantContext.class), eq(NAME), eq(TYPE), eq(request),
                eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)), eq(Optional.empty())))
                .thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, null, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileSearchingWithRangeAndPage() {

        Map<String, Object> request = createSearchRequest();
        request.put(PAGE, PAGE_NUMBER);
        com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse emptyServiceResponse =
                new com.ekart.facp.dashboard.service.dtos.DocumentSearchResponse(Lists.newArrayList(), 0);
        DocumentSearchResponse emptySearchResponse = new DocumentSearchResponse(emptyServiceResponse.getResponse(), 0);

        when(dashboardService.search(any(TenantContext.class), eq(NAME), eq(TYPE), eq(request),
                eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)), eq(Optional.of(PAGE_NUMBER))))
                .thenReturn(emptyServiceResponse);
        when(mapper.serviceSearchResponseToApiResponse(emptyServiceResponse)).thenReturn(emptySearchResponse);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, PAGE_NUMBER, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, emptySearchResponse);
    }

    @Test
    public void shouldSearchDocumentBasedOnSearchParamsWhileSearchingWithRangeAndPage() {

        Map<String, Object> request = createSearchRequest();
        request.put(PAGE, PAGE_NUMBER);
        DocumentSearchResponse expectedSearchResult = new DocumentSearchResponse(Lists.newArrayList(fieldMapPair), 0);
        when(dashboardService.search(any(TenantContext.class), eq(NAME),
                eq(TYPE), eq(request), eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)),
                eq(Optional.of(PAGE_NUMBER)))).thenReturn(searchResponse);
        when(mapper.serviceSearchResponseToApiResponse(searchResponse)).thenReturn(expectedSearchResult);
        ResponseEntity<DocumentSearchResponse> actualResponse = dashboardSearchController.searchWithRange(NAME,
                TYPE, CURRENT_TIME, CURRENT_TIME, PAGE_NUMBER, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, expectedSearchResult);
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileCountingWithoutRangeParams() {

        DocumentAggregationRequest request = createCountRequest();
        when(dashboardService.count(
                tenantContext, NAME, TYPE, request.getQueryParams(), Optional.empty(), Optional.empty(),
                request.getGroupByFields())).thenReturn(Lists.newArrayList());

        ResponseEntity<DocumentAggregatedResponse> actualResponse = dashboardSearchController.count(NAME,
                TYPE, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, new DocumentAggregatedResponse(Lists.newArrayList()));
    }

    @Test
    public void shouldReturnEmptyResponseIfNoCriteriaMetWhileCountingWithRangeParams() {

        DocumentAggregationRequest request = createCountRequest();
        when(dashboardService.count(tenantContext, NAME, TYPE, request.getQueryParams(),
                Optional.of(CURRENT_TIME), Optional.of(CURRENT_TIME),
                request.getGroupByFields())).thenReturn(Lists.newArrayList());

        ResponseEntity<DocumentAggregatedResponse> actualResponse = dashboardSearchController.count(NAME,
                TYPE, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK, new DocumentAggregatedResponse(Lists.newArrayList()));
    }

    @Test
    public void shouldReturnAggregatedResultBasedOnSearchParamsAndRangeParams() {

        DocumentAggregationRequest request = createCountRequest();
        when(dashboardService.count(
                any(TenantContext.class), eq(NAME), eq(TYPE), eq(request.getQueryParams()),
                eq(Optional.of(CURRENT_TIME)), eq(Optional.of(CURRENT_TIME)), eq(request.getGroupByFields())))
                .thenReturn(Lists.newArrayList(countResult));
        when(mapper.serviceCountResponseToApiResponse(countResult)).thenReturn(countApiResult);
        ResponseEntity<DocumentAggregatedResponse> actualResponse = dashboardSearchController.count(NAME,
                TYPE, request, CLIENT_KEY, TENANT_KEY);
        assertResponse(actualResponse, HttpStatus.OK,
                new DocumentAggregatedResponse(Lists.newArrayList(countApiResult)));
    }

    private Map<String, Object> createSearchRequest() {
        Map<String, Object> request = new HashMap<>();
        request.put("attributeKey", "attributeValue");
        return request;
    }

    private Map<String, Object> createNestedDocumentSearchRequest() {
        Map<String, Object> request = new HashMap<>();
        request.put("nestedKey", ImmutableMap.of("attributeKey", "attributeValue"));
        return request;
    }

    private DocumentAggregationRequest createCountRequest() {
        Map<String, Object> queryParams = createSearchRequest();
        List<String> groupByField = Lists.newArrayList("attributeKey");
        DocumentAggregationRequest request = new DocumentAggregationRequest();
        request.setQueryParams(queryParams);
        request.setGroupByFields(groupByField);
        request.setFromCreatedAt(CURRENT_TIME);
        request.setToCreatedAt(CURRENT_TIME);
        return request;
    }
}
