package com.ekart.facp.dashboard.daos.repository;

import static com.ekart.facp.dashboard.apis.config.CommonConfigValues.*;
import com.ekart.facp.dashboard.daos.models.BulkRecord;
import com.ekart.facp.dashboard.daos.models.Record;
import com.ekart.facp.dashboard.daos.models.SearchResult;
import com.ekart.facp.dashboard.service.exceptions.*;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import org.springframework.data.elasticsearch.ElasticsearchException;
import org.elasticsearch.index.Index;
import org.elasticsearch.index.query.*;
import org.elasticsearch.indices.IndexMissingException;
import org.elasticsearch.search.aggregations.Aggregations;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.data.elasticsearch.core.query.IndexQueryBuilder;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import static com.ekart.facp.dashboard.DashboardTestUtils.createRecord;
import static com.ekart.facp.dashboard.DashboardTestUtils.generateId;
import static com.ekart.facp.dashboard.service.utility.CommonHelper.withDocumentPrefix;
import static com.ekart.facp.dashboard.service.utility.Constants.CREATED_AT_EPOCH;
import static org.apache.commons.lang.builder.EqualsBuilder.reflectionEquals;
import static org.elasticsearch.search.aggregations.AggregationBuilders.terms;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by avinash.r on 05/05/16.
 */
@Repository
@RunWith(MockitoJUnitRunner.class)
public class RecordRepositoryImplTest {

    private static final String INDEX_NAME = "index";
    private static final String TYPE_NAME = "typeName";
    private static final String ATTRIBUTE_KEY = "attribute_key";
    private static final String DOCUMENT_ID = "id";
    private static final long CURRENT_TIME = 1L;
    private static final String SOURCE = "source";
    private static final long VERSION = 1;

    @Mock
    private ElasticsearchTemplate elasticsearchTemplate;

    @Mock
    private Aggregations aggregations;

    @Mock
    private Record record;

    @Mock
    private Map<String, Object> data;

    @Mock
    private ObjectMapper objectMapper;

    @Captor
    private ArgumentCaptor<SearchQuery> argumentCaptor;

    @Captor
    private ArgumentCaptor<IndexQuery> indexArgumentCaptor;

    @Captor
    private ArgumentCaptor<List<IndexQuery>> listArgumentCaptor;

    private RecordRepositoryImpl recordRepositoryImpl;

    private Index index;

    @Before
    public void setup() {

        recordRepositoryImpl = new RecordRepositoryImpl(elasticsearchTemplate, objectMapper);
        index = new Index(INDEX_NAME);
    }

    @Test(expected = IndexNotFoundException.class)
    public void shouldThrowErrorIfIndexNotPresentWhileSearching() {

        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(elasticsearchTemplate.query(any(SearchQuery.class), any(ResultsExtractor.class)))
                .thenThrow(new IndexMissingException(index));
        recordRepositoryImpl.search(
                INDEX_NAME, TYPE_NAME, ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, DEFAULT_PAGE);
    }

    //bulk index

    @Test(expected = InvalidInputException.class)
    public void shouldThrowErrorIfIndexSourceIsNotInProperFormatWhileIndexing() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenThrow(new JsonGenerationException("someException"));
        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowExceptionWhenIndexNotFound() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord.getId(),
                TYPE_NAME + ":id: IndexMissingException[[" + INDEX_NAME + "] missing]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowErrorWhenTypeNotFound() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord.getId()).withVersion(VERSION).withSource(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord.getId(),
                TYPE_NAME + ":id: TypeMissingException[[" + INDEX_NAME + "] type[[" + TYPE_NAME
                        + ", trying to auto create mapping, but dynamic mapping is disabled]] missing]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));

        IndexQuery actualQuery = listArgumentCaptor.getValue().get(0);
        assertIndexQuery(indexQueryBuilder.build(), actualQuery);
    }

    @Test
    public void shouldNotThrowErrorWhenCurrentAndProvidedVersionIsSame() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord.getId()).withVersion(VERSION).withSource(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord.getId(),
                TYPE_NAME + ":id: VersionConflictEngineException[[" + INDEX_NAME + "][0] type[[" + TYPE_NAME
                        + "][" + TYPE_NAME + ":id]: version conflict, current [1], provided [1]]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));

        IndexQuery actualQuery = listArgumentCaptor.getValue().get(0);
        assertIndexQuery(indexQueryBuilder.build(), actualQuery);
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowErrorWhenCurrentAndProvidedVersionIsDifferent() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord.getId()).withVersion(VERSION).withSource(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord.getId(),
                TYPE_NAME + ":id: VersionConflictEngineException[[" + INDEX_NAME + "][0] type[[" + TYPE_NAME
                        + "][" + TYPE_NAME + ":id]: version conflict, current [2], provided [1]]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));

        IndexQuery actualQuery = listArgumentCaptor.getValue().get(0);
        assertIndexQuery(indexQueryBuilder.build(), actualQuery);
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowErrorWhenHasUnknownErrorMessage() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord.getId()).withVersion(VERSION).withSource(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord.getId(),
                TYPE_NAME + ":id: Unknown[[" + INDEX_NAME + "]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));

        IndexQuery actualQuery = listArgumentCaptor.getValue().get(0);
        assertIndexQuery(indexQueryBuilder.build(), actualQuery);
    }

    @Test
    public void shouldIndexSingleDocument() throws JsonProcessingException {

        Record newRecord = createRecord(data, generateId(TYPE_NAME, "id"));

        when(objectMapper.writeValueAsString(newRecord)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord.getId()).withVersion(VERSION).withSource(SOURCE);

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord)));

        verify(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());
        IndexQuery actualQuery = listArgumentCaptor.getValue().get(0);
        assertIndexQuery(indexQueryBuilder.build(), actualQuery);
    }

    @Test(expected = BatchProcessingException.class)
    public void shouldThrowErrorWhileIndexMultipleDocuments() throws JsonProcessingException {

        Record newRecord1 = createRecord(data, generateId(TYPE_NAME, "id1"));
        Record newRecord2 = createRecord(data, generateId(TYPE_NAME, "id2"));
        Record newRecord3 = createRecord(data, generateId(TYPE_NAME, "id3"));

        when(objectMapper.writeValueAsString(newRecord1)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder1 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord1.getId()).withVersion(VERSION).withSource(SOURCE);

        when(objectMapper.writeValueAsString(newRecord2)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder2 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord2.getId()).withVersion(VERSION).withSource(SOURCE);

        when(objectMapper.writeValueAsString(newRecord3)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder3 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord3.getId()).withVersion(VERSION).withSource(SOURCE);

        doThrow(new ElasticsearchException("msg", ImmutableMap.of(newRecord2.getId(),
                TYPE_NAME + ":id: VersionConflictEngineException[[" + INDEX_NAME + "][0] type[[" + TYPE_NAME
                        + "][" + TYPE_NAME + ":id2]: version conflict, current [2], provided [1]]",
                newRecord1.getId(), TYPE_NAME + ":id1: IndexMissingException[[" + INDEX_NAME + "] missing]")))
                .when(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(
                        new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord1),
                        new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord2),
                        new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord3)));

        List<IndexQuery> actualQueries = listArgumentCaptor.getValue();

        assertIndexQuery(indexQueryBuilder1.build(), actualQueries.get(0));
        assertIndexQuery(indexQueryBuilder2.build(), actualQueries.get(1));
        assertIndexQuery(indexQueryBuilder3.build(), actualQueries.get(2));
    }

    public void shouldIndexMultipleDocuments() throws JsonProcessingException {

        Record newRecord1 = createRecord(data, generateId(TYPE_NAME, "id1"));
        Record newRecord2 = createRecord(data, generateId(TYPE_NAME, "id2"));
        Record newRecord3 = createRecord(data, generateId(TYPE_NAME, "id3"));

        when(objectMapper.writeValueAsString(newRecord1)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder1 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord1.getId()).withVersion(VERSION).withSource(SOURCE);

        when(objectMapper.writeValueAsString(newRecord2)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder2 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord2.getId()).withVersion(VERSION).withSource(SOURCE);

        when(objectMapper.writeValueAsString(newRecord3)).thenReturn(SOURCE);
        IndexQueryBuilder indexQueryBuilder3 = new IndexQueryBuilder().withIndexName(INDEX_NAME).withType(TYPE_NAME).
                withId(newRecord3.getId()).withVersion(VERSION).withSource(SOURCE);

        recordRepositoryImpl.bulkInsert(Lists.newArrayList(
                new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord1),
                new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord2),
                new BulkRecord(INDEX_NAME, TYPE_NAME, VERSION, newRecord3)));

        verify(elasticsearchTemplate).bulkIndex(listArgumentCaptor.capture());
        List<IndexQuery> actualQueries = listArgumentCaptor.getValue();

        assertIndexQuery(indexQueryBuilder1.build(), actualQueries.get(0));
        assertIndexQuery(indexQueryBuilder2.build(), actualQueries.get(1));
        assertIndexQuery(indexQueryBuilder3.build(), actualQueries.get(2));
    }

    @Test
    public void shouldReturnListOfDocumentsBasedOnSearchQueryParams() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(expectedResponse);
        SearchResult response = recordRepositoryImpl.search(
                INDEX_NAME, TYPE_NAME, ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, DEFAULT_PAGE);

        SearchQuery expectedQuery = buildSearchQuery(currentTime, currentTime).withIndices(INDEX_NAME).
                withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();

        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(response, is(expectedResponse));
    }

    @Test
    public void shouldReturnListOfDocumentsBasedOnOnlyRangeParams() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(expectedResponse);
        SearchResult response = recordRepositoryImpl.search(
                INDEX_NAME, TYPE_NAME, ImmutableMap.of(), currentTime, currentTime, DEFAULT_PAGE);

        SearchQuery expectedQuery = buildRangeQuery(currentTime, currentTime).withIndices(INDEX_NAME).
                withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();

        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(response, is(expectedResponse));
    }

    @Test
    public void shouldReturnListOfDocumentsBasedOnSearchParamsWithoutCreatedAt() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(expectedResponse);
        SearchResult response = recordRepositoryImpl.search(INDEX_NAME, TYPE_NAME, ImmutableMap.of(
                ATTRIBUTE_KEY, "blr"), Optional.ofNullable(CURRENT_TIME), Optional.empty(), DEFAULT_PAGE);

        SearchQuery expectedQuery = buildSearchQueryWithoutRange().withIndices(INDEX_NAME).
                withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();

        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(response, is(expectedResponse));
    }

    @Test
    public void shouldReturnListOfDocumentsBasedOnSearchParamsWithoutUpdatedAt() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(expectedResponse);
        SearchResult response = recordRepositoryImpl.search(INDEX_NAME, TYPE_NAME, ImmutableMap.of(
                ATTRIBUTE_KEY, "blr"), Optional.empty(), Optional.ofNullable(CURRENT_TIME), DEFAULT_PAGE);

        SearchQuery expectedQuery = buildSearchQueryWithoutRange().withIndices(INDEX_NAME).
                withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();

        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(response, is(expectedResponse));
    }

    @Test
    public void shouldReturnEmptyListOfDocumentsBasedOnSearchQueryParamsIfNoRecordIsPresent() {

        SearchResult expectedResponse = new SearchResult(Lists.newArrayList(record), 1);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(expectedResponse);
        SearchResult response = recordRepositoryImpl.search(
                INDEX_NAME, TYPE_NAME, ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, DEFAULT_PAGE);

        SearchQuery expectedQuery = buildSearchQuery(currentTime, currentTime).withIndices(INDEX_NAME).
                withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();

        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(response, is(expectedResponse));
    }

    @Test(expected = IndexNotFoundException.class)
    public void shouldThrowErrorIfIndexNotPresentWhileCounting() {

        when(elasticsearchTemplate.query(any(SearchQuery.class), any(ResultsExtractor.class)))
                .thenThrow(new IndexMissingException(index));
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        recordRepositoryImpl.count(INDEX_NAME, TYPE_NAME,
                ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, Lists.newArrayList(ATTRIBUTE_KEY));
    }

    @Test
    public void shouldReturnCountResponseBasedOnSearchQueryParams() {

        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(aggregations);
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        Aggregations actualAggregations = recordRepositoryImpl.count(INDEX_NAME, TYPE_NAME,
                ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, Lists.newArrayList(ATTRIBUTE_KEY));
        SearchQuery expectedQuery = buildSearchQuery(currentTime, currentTime).addAggregation(terms(ATTRIBUTE_KEY)
                .field(ATTRIBUTE_KEY)).withIndices(INDEX_NAME).withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();
        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(aggregations, is(actualAggregations));
    }

    @Test
    public void shouldReturnCountResponseWithMultipleGroupByFields() {

        when(elasticsearchTemplate.query(argumentCaptor.capture(), any(ResultsExtractor.class)))
                .thenReturn(aggregations);
        List<String> groupByFields = Lists.newArrayList(ATTRIBUTE_KEY, "appId");
        Optional<Long> currentTime = Optional.ofNullable(CURRENT_TIME);
        Aggregations actualAggregations = recordRepositoryImpl.count(INDEX_NAME, TYPE_NAME,
                ImmutableMap.of(ATTRIBUTE_KEY, "blr"), currentTime, currentTime, groupByFields);
        SearchQuery expectedQuery = buildSearchQuery(currentTime, currentTime).addAggregation(terms(ATTRIBUTE_KEY)
                .field(ATTRIBUTE_KEY).subAggregation(terms("appId")
                        .field("appId"))).withIndices(INDEX_NAME).withTypes(TYPE_NAME).build();
        SearchQuery actualQuery = argumentCaptor.getValue();
        assertThat(actualQuery.getQuery().toString(), is(expectedQuery.getQuery().toString()));
        assertThat(aggregations, is(actualAggregations));
    }

    private NativeSearchQueryBuilder buildSearchQuery(Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt) {

        BoolFilterBuilder boolFilterBuilder = new BoolFilterBuilder().must(
                new TermFilterBuilder(withDocumentPrefix(ATTRIBUTE_KEY), "blr"));
        QueryBuilder qb = QueryBuilders.rangeQuery(withDocumentPrefix(CREATED_AT_EPOCH))
                .from(fromCreatedAt.get()).to(toCreatedAt.get());
        NativeSearchQueryBuilder queryBuilder = new NativeSearchQueryBuilder().
                withQuery(new FilteredQueryBuilder(qb, boolFilterBuilder));
        return queryBuilder;
    }

    private NativeSearchQueryBuilder buildRangeQuery(Optional<Long> fromCreatedAt, Optional<Long> toCreatedAt) {

        QueryBuilder qb = QueryBuilders.rangeQuery(withDocumentPrefix(CREATED_AT_EPOCH))
                .from(fromCreatedAt.get()).to(toCreatedAt.get());
        NativeSearchQueryBuilder queryBuilder = new NativeSearchQueryBuilder().
                withQuery(new FilteredQueryBuilder(qb, null));
        return queryBuilder;
    }

    private NativeSearchQueryBuilder buildSearchQueryWithoutRange() {

        BoolFilterBuilder boolFilterBuilder = new BoolFilterBuilder().must(
                new TermFilterBuilder(withDocumentPrefix(ATTRIBUTE_KEY), "blr"));
        NativeSearchQueryBuilder queryBuilder = new NativeSearchQueryBuilder().
                withQuery(new FilteredQueryBuilder(null, boolFilterBuilder));
        return queryBuilder;
    }

    private void assertIndexQuery(IndexQuery actualQuery, IndexQuery expectedQuery) {

        assertThat(reflectionEquals(actualQuery.getObject(), expectedQuery.getObject()), is(true));
        assertThat(actualQuery.getId(), is(expectedQuery.getId()));
        assertThat(actualQuery.getIndexName(), is(expectedQuery.getIndexName()));
        assertThat(actualQuery.getType(), is(expectedQuery.getType()));
        assertThat(actualQuery.getParentId(), is(expectedQuery.getParentId()));
        assertThat(actualQuery.getSource(), is(expectedQuery.getSource()));
        assertThat(actualQuery.getVersion(), is(expectedQuery.getVersion()));
    }

}
